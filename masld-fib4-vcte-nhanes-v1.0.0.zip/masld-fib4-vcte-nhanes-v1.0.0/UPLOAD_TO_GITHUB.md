# Upload and archive the reproducibility repository

## Before uploading

1. Confirm the author names in `LICENSE` and `CITATION.cff`.
2. Confirm the repository URL in `CITATION.cff`.
3. Confirm that `data/raw` and `data/derived` contain only `.gitkeep`.
4. Run `python run_all.py` once and inspect all CSV and figure outputs.
5. Confirm that no patient-level data, credentials, tokens or local paths are
   present in tracked files.

## Option A: GitHub website plus Git command line

Create an empty public repository at <https://github.com/new>. Suggested name:
`masld-fib4-vcte-nhanes`. When importing this prepared local directory, do not
pre-populate the GitHub repository with a README, license or `.gitignore`,
because these files already exist locally.

Open a terminal in this repository and run each command separately:

```bash
git init
git branch -M main
git add .
git status
git commit -m "Release reproducible NHANES MASLD analysis code"
git remote add origin https://github.com/YOUR_USERNAME/masld-fib4-vcte-nhanes.git
git push -u origin main
```

GitHub no longer accepts account passwords for Git HTTPS operations. Use the
browser/device login offered by Git Credential Manager, a personal access
token, or SSH authentication.

## Option B: GitHub CLI

Install and authenticate GitHub CLI, then run:

```bash
gh auth login
git init
git branch -M main
git add .
git status
git commit -m "Release reproducible NHANES MASLD analysis code"
gh repo create masld-fib4-vcte-nhanes --public --source=. --remote=origin --push
```

## Create a permanent version

After checking the public repository:

```bash
git tag -a v1.0.0 -m "Version used for manuscript submission"
git push origin v1.0.0
```

On GitHub, open **Releases**, select **Draft a new release**, choose tag
`v1.0.0`, add a concise description, and publish the release. Cite this tagged
release rather than the moving `main` branch.

## Archive with Zenodo and obtain a DOI

1. Sign in to Zenodo using the GitHub option.
2. In Zenodo's GitHub settings, enable the repository.
3. Publish a GitHub release after enabling the repository.
4. Zenodo will archive the release and assign a version-specific DOI and a
   concept DOI.
5. Add the DOI badge and DOI to the GitHub README and `CITATION.cff`.
6. Use the version-specific DOI in the submitted manuscript.

Recommended manuscript wording:

> The complete analysis code is available at the versioned GitHub release
> [URL] and permanently archived in Zenodo [DOI], version 1.0.0. NHANES source
> data are publicly available from CDC/NCHS and are downloaded by the supplied
> script; participant-level derived files are not redistributed.

## Updating after peer review

Commit revision changes normally, rerun the full pipeline, and create a new
tag such as `v1.1.0`. Do not overwrite or delete the version cited in the
original submission. Update the response letter and Code Availability statement
to identify the exact version used for the revised manuscript.
